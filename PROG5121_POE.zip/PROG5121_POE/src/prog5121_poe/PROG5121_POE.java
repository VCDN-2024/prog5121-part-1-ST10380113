
package prog5121_poe;

import javax.swing.JOptionPane;

public class PROG5121_POE {

    public static void main(String[] args) {
        //create an object for the class 'Login' 
        Login check = new Login();
        
        //call method 'registerUser()'
        String registerUser = check.registerUser();
        JOptionPane.showMessageDialog(null, registerUser);
        
        //call method 'returnLoginStatus()'
        String loginStatus = check.returnLoginStatus();
        //display to the user whether they have successfully logged in or not, this is received from the method called above
        JOptionPane.showMessageDialog(null, loginStatus);
    }    
}
