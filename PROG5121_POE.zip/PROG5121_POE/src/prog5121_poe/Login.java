
package prog5121_poe;


import javax.swing.JOptionPane;

public class Login {
    //create variables to store user inputs
    String Username = JOptionPane.showInputDialog("Enter your username:");;
    String Password = JOptionPane.showInputDialog("Enter your password");
    String firstName = JOptionPane.showInputDialog("Enter your first name:");
    String lastName = JOptionPane.showInputDialog("Enter your last name:");
            
    public boolean checkUserName(String Username){ 
        //check to see if the username entered by the user is not more than 5 characters and contains an underscore, returns true otherwise returns false
        if (Username == null){
            return false;
        }
        return Username.length() <= 5 && Username.contains("_");
    }
    
    public boolean checkPasswordComplexity(String Password){
        //checks to see if the password entered by the user is more than 8 characters long, contains at least uppercase letter, one digit and one special character, returns true otherwise false
        if (Password == null){
            return false;
        }
        boolean hasLength = Password.length() >= 8;
        boolean hasUppercase = !Password.equals(Password.toLowerCase());
        boolean hasNumber = Password.matches(".*\\d.*");
        boolean hasSpecial = !Password.matches("[a-zA-Z0-9 ]*");
        
        return hasLength && hasUppercase && hasNumber && hasSpecial;        
    }    
    
    public boolean loginUser(String inputUsername, String inputPassword){
        //checks to see if the username and password entered by the user matches the one stored in the variables username and password, returns true otherwise false
        if(inputUsername.equals(Username) && inputPassword.equals(Password)){
            return true;
        }else{
            return false;
        }
    }
    
    //creates a method to register a new user
    public String registerUser(){
        //if the password and username meets the requirements set out in the 'checkPasswordComplexity()' and 'checkUserName()' method a success message is displayed to the user, otherwise an error message is displayed
        if(checkPasswordComplexity(Password) && checkUserName(Username)){
            this.Password = Password;
            this.Username = Username;
            return "Password and Username successfully captured";
        }else{
            return "Password or username is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        }
    }
    
    public String returnLoginStatus(){
        //check to see if the username and password has been entered
        if(Username.isEmpty() || Password.isEmpty()) {
        return "Please enter both username and password.";
    }
        
    // Now, attempt to login the user
    if(loginUser(Username, Password)){
        // If login successful, display welcome message
        return "Welcome " + firstName + " " + lastName + ". It is great to see you again.";
    } else {
        // If login fails, display error message
        return "Username or password incorrect, please try again.";
    }
}

}
